/****************************************************************************/
/*                                                                          */
/*  Vesabase.c lists all available 256 color modes and let you choose one   */
/*  of them. If VESA is not detected then mode 13h is automatically chosen. */
/*  The chooseMode function sets up a number of global variables so it is   */
/*  possible to write the rest of the code independent of the videomode.    */
/*  The main function only draws a pattern over the entire screen, it's     */
/*  only meant to be a base that you can build your own code on.            */
/*  Things to do: add cool palettes, fades and paletterotations.            */
/*  For example, try to implement the program from the demoschool part 1    */
/*  but in SVGA. It should be pretty easy.                                  */
/*                                                                          */
/*                    September 1996    Abe Racadabra                       */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <conio.h>

/*--------------------------------------------------------------------------*/

typedef struct {
	char signature[4];	//letters VESA
	short version;		//version: hight byte.low byte
	char far *oem;		//name of the card
	long capabilities;
	unsigned far *videomodes; //pointer to available modes
	short totalmemory;
	char reserved[236];
} vesaInfo;


typedef struct {
	unsigned short mode;
	unsigned char  wina;
	unsigned char  winb;
	unsigned short granularity;	//granularity and winsize are used
	unsigned short winsize;		//to calculate the banksift value
	unsigned short winasegment;
	unsigned short winbsegment;
	void (far *bankSwitch)(void);	//pointer to bankSwitch routine
	unsigned short bytesperline;
	unsigned short width;		//width and
	unsigned short height;		//height of the videomode
	unsigned char  charwidth;
	unsigned char  charheight;
	unsigned char  bitplanes;
	unsigned char  bitsperpixel;	//if this is 8 then it's 256 colors
	unsigned char  banks;
	unsigned char  memorymodel;
	unsigned char  banksize;
	unsigned char  imagepages;
	unsigned char  reserved1;
	unsigned char  redmasksize;
	unsigned char  redfieldposition;
	unsigned char  greenmasksize;
	unsigned char  greenfieldposition;
	unsigned char  bluemasksize;
	unsigned char  bluefieldposition;
	unsigned char  rsvdmasksize;
	unsigned char  rsvdfieldposition;
	unsigned char  directcolormode;
	unsigned char  reserved2[216];
} modeInfo;

/*--------------------------------------------------------------------------*/

/* Global variables */
void (far *switchBank)(void);	//function pointer to bankswitch routine
void (*putpixel)(int x,int y,char color); //pointer to putpixel routine
int bank,bankshift;		//global variables used for bankswitching
int scr_w,scr_h;		//width and height of the screen

/*--------------------------------------------------------------------------*/

/* this is the slow way to switch bank */
/* setbank is used by slow_putpixel_vesa_256 (which is not used) */
void setbank(void)   // the bank that shall be set is a global variable
{
asm mov ax,4f05h     // VESA switch bank
asm xor bx,bx        // bx should be 0
asm mov dx,[bank]    // dx = bank (global variable)
asm mov cx,[bankshift] // bankshift is calculated in the chooseMode routine
asm shl dx,cl	     // dx = bank*(winsize/granularity)
asm int 10h          // and do it
}

/*--------------------------------------------------------------------------*/

/* The adress is calculated with is 640*y + x */
/* a mul works great because it puts the high 16 bits of a mul in dx */
/* and the low 16 bits in ax */
/* after the mul, dx will contain the bank number */
/* and ax will be the offset into that bank */
void putpixel_vesa_256(int x,int y, char col)
{
int ofs;
asm mov ax,[scr_w]
asm mov bx,[y]
asm mul bx         // ax = 640*y, dx = bank
asm add ax,[x]     // ax = (640*y + x)%(64k)
asm jnc noc        // if the add went into a new bank (carry set)
asm inc dx         // then bank = bank + 1
noc:
asm mov ofs,ax     // mov ax (offset into bank) to ofs
asm cmp dx,[bank]  // compare this pixel's bank to the current bank
asm jz same        // if it's the same, don't set the bank
asm mov [bank],dx  // else update bank

asm mov cx,[bankshift] // direct banking, faster than the "int 10h" method
asm shl dx,cl
asm xor bx,bx
switchBank();  // call the bankswitch routine (got it from getVesaModeInfo)

same:
asm push di	//save di or else the program can crash
asm mov ax,0a000h  // and put the pixel into a000:offset
asm mov es,ax
asm mov di,[ofs]
asm mov al,[col]
asm mov [es:di],al
asm pop di	//restore di
}

/*--------------------------------------------------------------------------*/

/* uses the slow bankswitch method */
/* this routine is not used in this program */
/* but it could be fun to compare the speed between the two routines */
/* it's almost the same because 99% of the times you don't switch bank */
void slow_putpixel_vesa_256(int x,int y, char col)
{
int ofs;
asm mov ax,[scr_w]
asm mov bx,[y]
asm mul bx         // ax = 640*y, dx = bank
asm add ax,[x]     // ax = (640*y + x)%(64k)
asm jnc nocry      // if the add went into a new bank (carry set)
asm inc dx         // then bank = bank + 1
nocry:
asm mov ofs,ax     // mov ax (offset into bank) to ofs
asm cmp dx,[bank]  // compare this pixel's bank to the current bank
asm jz samma       // if it's the same, don't set the bank
asm mov [bank],dx  // else update bank
setbank();	   // set new bank with vesa function 0xf405
samma:
asm push di
asm mov ax,0a000h  // and put the pixel into a000:offset
asm mov es,ax
asm mov di,[ofs]
asm mov al,[col]
asm mov [es:di],al
asm pop di
}

/*--------------------------------------------------------------------------*/

/* This is the putpixel for mode 13h that I beleive you are familliar with */
void putpixel_13h(int x, int y, char col)
{
asm	mov	ax,0a000h
asm	mov	es,ax
asm	mov	bx,[y]
asm	mov	di,bx
asm	shl	bx,8	//bx = 256*y
asm	shl	di,6	//di = 64*y
asm	add	di,bx	//di = (256 + 64)*y = 320*y
asm	add	di,[x]	//di = 320*y + x
asm	mov	al,[col]
asm	mov	[es:di],al
}

/*--------------------------------------------------------------------------*/

int getVesaInfo(vesaInfo far *vesainfo)
{
 asm	mov ax,04f00h	//ax = 0x4f00
 asm	les di, vesainfo//es:di -> vesainfo
 asm	int 10h		//call interrupt and get vesainfo
 asm	cmp ax,4fh	//if ax is 0x4f then vesa is detected
 asm	jz done
 return(0);		//if not, return 0 (no vesa card detected)
done:
return(1);	//successful, return 1
}

/*--------------------------------------------------------------------------*/

int getVesaModeInfo(int mode, modeInfo far *modeinfo)
{
 asm	mov ax,4f01h
 asm	mov cx,[mode]
 asm	les di,modeinfo
 asm	int 10h
 return (modeinfo->mode & 1); //return 1 if successful, else 0
}

/*--------------------------------------------------------------------------*/

void setVesaMode(int mode)
{
asm mov ax,4f02h
asm mov bx,[mode]
asm int 10h
}

void setmode(int mode)
{
asm mov ax,[mode]
asm int 10h
}

/*--------------------------------------------------------------------------*/

void printFarString(char far* str)
{
 int i;
 for(i=0;str[i]!=0;i++) printf("%c",str[i]);
}

/*--------------------------------------------------------------------------*/

/* lists all available 256-color modes and let you choose one of them */
void chooseMode(void)
{
 vesaInfo vesainfo;
 modeInfo modeinfo;
 unsigned far *mode;
 int modes[100];
 int i;

 for(i=0;i<100;i++) modes[i]=-1; //initialize all modes to -1

 if(!getVesaInfo(&vesainfo))//If the card is not VESA compatible, choose 13h
 {
	printf("No VESA VBE detected...choosing mode 13h\n");
	getch();	//wait for the user to read this depressing message
	scr_w=320;	//set screen width and height
	scr_h=200;
	putpixel=putpixel_13h; //set the putpixel function pointer
	setmode(0x013);//use old setmode routine, card is not VESA compatible
 }
 else
 {      //card is VESA compatible, print version number
	printf("\nVESA VBE version %d.%d (", vesainfo.version >> 8, vesainfo.version & 0xf);
	printFarString(vesainfo.oem);	//And Name of the card
	printf(") detected\n\n");

	printf("Choose video mode:\n");
	printf("key\tmode\twidth\theight\tcolors\n");
	printf("0\t13h\t320\t200\t256\n"); //First print info about mode 13h
	modes[0]=0x013; //put mode 13h at index 0 in the modes array
	i=1;	//let the vesa modes start at index 1
	//loop through all available videomodes
	for(mode=vesainfo.videomodes;*mode!=(unsigned)-1;mode++)
	{
		//Print info about all 256 color modes (8 bitsperpixel)
		if(getVesaModeInfo(*mode,&modeinfo) && modeinfo.bitsperpixel==8)
		{
		 modes[i]=*mode; //save the modenumber in the modes array
		 printf("%d\t%Xh\t%d\t%d\t",i,*mode, modeinfo.width, modeinfo.height);
		 switch(modeinfo.bitsperpixel)
		 {
		  case 4: printf("16\n"); break;
		  case 8: printf("256\n"); break;
		  case 15: printf("32K\n"); break;
		  case 16: printf("64K\n"); break;
		  case 24: printf("16M\n"); break;
		  default: printf("modeinfo.bitsperpixel bits per pixel\n");
		 }
		 i++; //and increase index for the modes array
		}
	}

 //let the user choose one of the printed modes by pressing the indexnumber
 //0,1,2,3 ...
 //repeat until the user has input a valid index (modes[i]!=-1)
 while(modes[i]==-1) //scanf sucks!!! if you're serious
 {                   //then write your own readnumber routine using getch().
  printf("mode: ");  //this code will crash if you enter, for instance, 13h
  scanf("%d",&i);    //you should enter the indexnumber...
 }

 if(modes[i]==0x013) //card is VESA compatible and mode 13h is chosen
 {
	scr_w=320;   //set up the global variables
	scr_h=200;
	putpixel=putpixel_13h; //and the putpixel function pointer
	setmode(0x013);
 }
 else	//card is VESA compatible and a VESA mode is chosen
 {
	getVesaModeInfo(modes[i],&modeinfo); //get info about the chosen mode
	scr_w=modeinfo.width;	//set up screen width and height
	scr_h=modeinfo.height;
	putpixel=putpixel_vesa_256;	//set the putpixel functionpointer
	switchBank=modeinfo.bankSwitch; //and the bankswitch function pointer
	setVesaMode(modes[i]);		//set the chosen VESA mode
	// when calling the bankswitch routine, dx should be
	// bank * (winsize/granularity). winsize/granularity
	// is always a power of 2 so it's possible to shift instead of mul
	i = modeinfo.winsize/modeinfo.granularity;
	switch(i)                      //set the bankshift value
	{
		case 1: bankshift=0; break;
		case 2: bankshift=1; break;
		case 4: bankshift=2; break;
		case 8: bankshift=3; break;
		case 16: bankshift=4; break;
		case 32: bankshift=5; break;
		case 64: bankshift=6; break;
		default: bankshift=0; //this should not happen...
	}
 }

 }
}

/*--------------------------------------------------------------------------*/

void main(void)
{
int i,j;
clrscr();
chooseMode(); // choose mode and setup the global variables

//draw pixels on the entire screen just to see that the putpixelroutine works.
//Put your own code from here on...
//Notice that you just have to use scr_w, scr_h and putpixel and it works
//for all of the modes, no matter which mode is chosen.
for(i=0;i<scr_w;i++)
{
 for(j=0;j<scr_h;j++) putpixel(i,j,j*i);
}

getch();
setmode(3);
}
