/**************************************************************************/
/*                                                                        */
/* Detect.c detects if VESA is available and if it is, which VESA modes   */
/* are available and prints modes number, width, height and colors.       */
/*                                                                        */
/*                    September 1996    Abe Racadabra                     */
/*                                                                        */
/**************************************************************************/

#include <stdio.h>

typedef struct {
	char signature[4];	//VESA
	short version;		//VESA version
	char far *oem;		//Name of the card
	long capabilities;
	unsigned far *videomodes; //pointer to available videomodes
	short totalmemory;
	char reserved[236];
} vesaInfo;

typedef struct {
	unsigned short mode;
	unsigned char  wina;
	unsigned char  winb;
	unsigned short granularity;	//granularity and winsize are used
	unsigned short winsize;		//to calculate the banksift value
	unsigned short winasegment;
	unsigned short winbsegment;
	void (far *bankSwitch)(void);	//pointer to bankSwitch routine
	unsigned short bytesperline;
	unsigned short width;		//width and
	unsigned short height;		//height of the videomode
	unsigned char  charwidth;
	unsigned char  charheight;
	unsigned char  bitplanes;
	unsigned char  bitsperpixel;	//if this is 8 then it's 256 colors
	unsigned char  banks;
	unsigned char  memorymodel;
	unsigned char  banksize;
	unsigned char  imagepages;
	unsigned char  reserved1;
	unsigned char  redmasksize;
	unsigned char  redfieldposition;
	unsigned char  greenmasksize;
	unsigned char  greenfieldposition;
	unsigned char  bluemasksize;
	unsigned char  bluefieldposition;
	unsigned char  rsvdmasksize;
	unsigned char  rsvdfieldposition;
	unsigned char  directcolormode;
	unsigned char  reserved2[216];
} modeInfo;


int getVesaInfo(vesaInfo far *vesainfo)
{
 asm	mov ax,04f00h		//ax = 0x4f00
 asm	les di, [vesainfo]	//es:di -> vesainfo
 asm	int 10h			//call interrupt and get vesainfo
 asm	cmp ax,4fh		//if ax is 0x4f then vesa is detected
 asm	jz done
 return(0);			//if not, return 0 (no vesa card)
done:
 return(1);		//successful, return 1
}

int getVesaModeInfo(int mode, modeInfo far *modeinfo)
{
 asm	mov ax,4f01h
 asm	mov cx,[mode]
 asm	les di,[modeinfo]
 asm	int 10h
 return (modeinfo->mode & 1); //return 1 if succesful, else 0
}

/* I couldn't get printf to print a far string so I wrote this function */
void printFarString(char far* str)
{
 int i;
 for(i=0;str[i]!=0;i++) printf("%c",str[i]);
}

void availModes(void) {
 vesaInfo vesainfo;
 modeInfo modeinfo;
 unsigned far *mode;

 if(!getVesaInfo(&vesainfo)) printf("No VESA VBE detected...\n");
 else
 {      //print VESA version of the card
	printf("\nVESA VBE version %d.%d (", vesainfo.version >> 8, vesainfo.version & 0xf);
	printFarString(vesainfo.oem);	//print name of the card
	printf(") detected\n\n");

	printf("Available VESA videomodes:\n");
	printf("mode\twidth\theight\tcolors\n");
	//loop through all available videomodes
	for( mode = vesainfo.videomodes ; *mode != (unsigned)-1 ; mode++ )
	{
		if(getVesaModeInfo(*mode,&modeinfo)) //get info about a mode
		{
			//and print some of the info
			printf("%Xh\t%d\t%d\t",*mode, modeinfo.width, modeinfo.height);
			switch(modeinfo.bitsperpixel)
			{
			case 4: printf("16\n"); break;	//number of colors
			case 8: printf("256\n"); break;
			case 15: printf("32K\n"); break;
			case 16: printf("64K\n"); break;
			case 24: printf("16M\n"); break;
			default: printf("%d bits per pixel\n",modeinfo.bitsperpixel);
			}
		}
	}
 }
}

void main(void)
{
availModes();	//detect VESA and print info about the available modes
}
