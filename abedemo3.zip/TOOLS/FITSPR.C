/* Change the names in the beginning of main to your own sprite and 
palette names if you try to use this program.

This is not a part of the demoschool, only a helpprogram that probably
doesn't work perfectly.
The comment's doesn't exist or are in swedish
*/


#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<math.h>


unsigned char TGAHdrData[2048];
int width;
int height;


struct TGAHdrType {
	short int       NumOfBytInId;
	short int       ColorMapType;
	short int       ImageTypeCode;
	unsigned int    ColorMapOrigin;
	unsigned int    ColorMapLength;
	short int       ColorMapEntrySize;
	unsigned int    XStart;
	unsigned int    YStart;
	unsigned int    Width;
	unsigned int    Height;
	short int       PixelSize;
	short int       ImageDescriptor;
	unsigned int    PaletteStart;
	unsigned int    DataStart;

};


void wtsync(void)
{
asm{

					 mov     dx,3DAh
}
WaitVR1:
asm{
					 in      al,dx
		test    al,8
		jne     WaitVR1
}
WaitVR2:
asm{
		in      al,dx
		test    al,8
		je      WaitVR2
}
}

void setmode(int mode)
{
	asm{
		mov     ax,mode
		int     10h
	}
}

void putpixel(int x,int y,unsigned char color)
{
asm{
	mov     ax,0a000h
	mov     es,ax
	mov     ax,y
	mov     di,ax
	xchg ah,al      //ax=256*y
	shl  di,6       //ax=di*y
	add  di,ax      //di=320*y
	add  di,x
	mov     al,color
	stosb
}
}

unsigned char getpixel(int x,int y)
{
unsigned char color;
asm{
	push    ds
	mov     ax,0a000h
	mov     ds,ax
	mov     ax,y
	mov     si,ax
	xchg ah,al      //ax=256*y
	shl  si,6       //ax=di*y
	add  si,ax      //si=320*y
	add  si,x      // +x
	lodsb
	mov     color,al
	pop     ds
}
return(color);
}

//sparar sk�rmen fr�n 0,0 width,height, huvud: height,width
void savepic(char*namn)
{
int i,j;
FILE *fs;

	if(!(fs = fopen(namn, "wb")))
	  {
	  printf("Kan ej �ppna filen %s\n",namn);
	  getch();
	  exit(1);
	  }

	fwrite(&height, 2, 1, fs);      //hyvud: h�jd
	fwrite(&width, 2, 1, fs);     //bredd

for(j=0;j<height;j++)              //data
{
	  for(i=0;i<width;i++) TGAHdrData[i]=getpixel(i,j);
	  fwrite(TGAHdrData, width, 1, fs);
}
   fclose(fs);
}

void loadpic(char*namn)
{
int i,j;
FILE *fs;

	if(!(fs = fopen(namn, "rb")))
	  {
	  printf("Kan ej �ppna filen %s\n",namn);
	  getch();
	  exit(1);
	  }

	fread(&height, 2, 1, fs);       //hyvud: h�jd
	fread(&width, 2, 1, fs);     //bredd

for(j=0;j<height;j++)              //data
{
	  fread(TGAHdrData, width, 1, fs);
	  for(i=0;i<width;i++) putpixel(i,j,TGAHdrData[i]);
}
   fclose(fs);
}

void read_TGAHdr(struct TGAHdrType * TGAHdr, char * filename)
{
   FILE *fs;

   if (!(fs = fopen(filename, "rb")))
	  {
	  printf("Kan ej �ppna filen %s\n",filename);
	  getch();
	  exit(1);
	  }

   if (fread(TGAHdrData, 786, 1, fs) != 1)
	  {
	  printf("Kan ej l�sa TGA-headern");
	  getch();
	  exit(1);
	  }

   TGAHdr->NumOfBytInId      = TGAHdrData[0];
   TGAHdr->ColorMapType      = TGAHdrData[1];
   TGAHdr->ImageTypeCode     = TGAHdrData[2];
   TGAHdr->ColorMapOrigin    = TGAHdrData[3]+256*TGAHdrData[4];
   TGAHdr->ColorMapLength    = TGAHdrData[5]+256*TGAHdrData[6];
   TGAHdr->ColorMapEntrySize = TGAHdrData[7];
   TGAHdr->XStart            = TGAHdrData[8]+256*TGAHdrData[9];
   TGAHdr->YStart            = TGAHdrData[10]+256*TGAHdrData[11];
   TGAHdr->Width             = TGAHdrData[12]+256*TGAHdrData[13];
   TGAHdr->Height            = TGAHdrData[14]+256*TGAHdrData[15];
   TGAHdr->PixelSize         = TGAHdrData[16];
   TGAHdr->ImageDescriptor   = TGAHdrData[17];
   TGAHdr->PaletteStart      = 18 + TGAHdr->NumOfBytInId;
   TGAHdr->DataStart         = 18 + TGAHdr->NumOfBytInId + 3 * TGAHdr->ColorMapLength;

   fclose(fs);
}


void TGAHdr_to_pal_256(struct TGAHdrType TGAHdr,unsigned char*pal)
{
   int p; //loopcounter
   int red, green, blue; //to set the palett

   for (p=0; p<256; p++)
   {
		red   = (TGAHdrData[TGAHdr.PaletteStart+2+(p*3)]);
		green = (TGAHdrData[TGAHdr.PaletteStart+1+(p*3)]);
		blue  = (TGAHdrData[TGAHdr.PaletteStart+0+(p*3)]);

		pal[p*3]=red>>2;         //red/4
		pal[p*3+1]=green>>2;
		pal[p*3+2]=blue>>2;
   }
}



void show_TGA_image_256_uncom(struct TGAHdrType TGAHdr, char * filename, int xpos, int ypos)
{
   int i, j, rad; //loopr�knare

   FILE *fs;

   if (!(fs = fopen(filename, "rb")))
	  {
	  printf("Kan ej �ppna filen\n");
	  exit(1);
	  }

	// S�tter filpekaren
	fseek(fs, TGAHdr.DataStart, SEEK_SET);

	if ((TGAHdr.ImageDescriptor&32)==32) {
		//ritar uppifr�n och ned�t
		rad=ypos;
		for (i=ypos; i<ypos+TGAHdr.Height; i++)
		{
			//L�ser in en rad
			fread(TGAHdrData, TGAHdr.Width, 1, fs);
			//Ritar ut raden
			for (j=0; j < TGAHdr.Width; j++)
			{
				putpixel(xpos+j,i,TGAHdrData[j]);
			}
		}
	}
	else {
		//ritar nerifr�n och upp�t
		rad=ypos+TGAHdr.Height;
		for (i=rad; i>rad-TGAHdr.Height; i--)
		{
			//L�ser in en rad
			fread(TGAHdrData, TGAHdr.Width, 1, fs);
			//Ritar ut raden
			for (j=0; j < TGAHdr.Width; j++)
			{
				putpixel(xpos+j,i,TGAHdrData[j]);
			}
		}
	}
	fclose(fs);
}

void show_TGA_image_256_rle(struct TGAHdrType TGAHdr, char * filename, int xpos, int ypos)
{
	int rad, kol, dir, i;
	char pakethdr;
	short int pakettyp;
	short int hdrnumber;
	short int rlecolor;

	FILE *fs;

	if (!(fs = fopen(filename, "rb")))
	{
		printf("Kan ej �ppna filen\n");
		exit(1);
	}

	// S�tter filpekaren
	fseek(fs, TGAHdr.DataStart, SEEK_SET);

	//B�rja i �vre eller undre v�nstra h�rnet;Kolla bit 5
	if ((TGAHdr.ImageDescriptor&32)==32) {
		rad=ypos;
		dir=1;
	}
	else {
		rad=ypos+TGAHdr.Height;
		dir=-1;
	}

	kol=0;

	while (!feof(fs)) {
		//L�s in pakethuvud
		fread(&pakethdr, 1, 1, fs);
		pakettyp = pakethdr&128;
		hdrnumber = pakethdr&127;
		if (pakettyp==0) {
			//L�s in raw_body
			fread(TGAHdrData, hdrnumber+1, 1, fs);
			//Rita ut paketet
			for (i=0; i<hdrnumber+1; i++) {
				putpixel(xpos+kol,rad,TGAHdrData[i]);
				kol++;
				if ((kol%TGAHdr.Width==0) && (kol!=0)) {
					rad=rad+dir;
					kol=0;
				}
			}
		}
		else {
			//L�s in rle_body
			fread(&rlecolor, 1, 1, fs);
			//Rita ut paketet
			for (i=0; i<hdrnumber+1; i++) {
				putpixel(xpos+kol,rad,rlecolor);
				kol++;
				if ((kol%TGAHdr.Width==0) && (kol!=0)) {
					rad=rad+dir;
					kol=0;
				}
			}
		}
	}
	fclose(fs);
}


void ViewTgaNGetPal(char*image, unsigned char*pal)
{
	struct TGAHdrType TGAHdr;

	//L�ser TGA-bildens header
	read_TGAHdr(&TGAHdr,image);
	width=TGAHdr.Width;
	height=TGAHdr.Height;

	switch (TGAHdr.ImageTypeCode)
	{
		case 1:
			TGAHdr_to_pal_256(TGAHdr,pal);
			show_TGA_image_256_uncom(TGAHdr,image,0,0);
			break;
		case 9:
			TGAHdr_to_pal_256(TGAHdr,pal);
			show_TGA_image_256_rle(TGAHdr,image,0,0);
			break;

		default:
			printf("\nDet targaformatet klarar jag inte av!!\n");
	}
}



void loadpalett(char*filename,unsigned char*pal)
{
int i;
unsigned char palett[256*3];
FILE *fs;

   if (!(fs = fopen(filename, "rb")))
	  {
	  printf("Kan ej �ppna filen %s\n",filename);
	  getch();
	  exit(1);
	  }

fread(palett, 256*3, 1, fs);
fclose(fs);

for(i=0;i<256*3;i++) pal[i]=palett[i];
}


void setpal(unsigned char*palett)
{
int i;

outp(0x3c8,0);
for(i=0;i<256*3;i++)
	outp(0x3c9,palett[i]);
}

void showpal(void)
{
int i,j,h,b,ypos;
b=5;
h=4;
ypos=199-16*h;
for(i=0;i<16*b;i++)
{
	for(j=0;j<16*h;j++)
	{
	if(i%b!=0 && j%h!=0) putpixel(i,j+ypos,i/b+(j/h)*16);
	}
}
}


void rotpal(char*pal,int first, int last)
{
char r,g,b;
int i;

r=pal[first*3 + 0];                     //s�tt r,g,b till f�rsta f�rgen (f�rg 0)
g=pal[first*3 + 1];
b=pal[first*3 + 2];

for(i=first*3;i<(last+1)*3;i++) //flytta ner alla f�rger ett steg
pal[i]=pal[i+3];

pal[last*3+0]=r;        //s�tt sista f�rgen (255) till r,g,b
pal[last*3+1]=g;
pal[last*3+2]=b;

wtsync();
setpal(pal);
}


void get_TGA_colors(int*colors)
{
int m,n,j;

colors[256]=1;                  //antal f�rger hittills i colors[256]
colors[0]=getpixel(0,0);

for(n=1;n<height;n++)
{
for(m=0;m<width;m++)
{
	for(j=0;j<colors[256] && colors[j]!=getpixel(m,n);j++);
	if(j==colors[256])
	{
		colors[colors[256]]=getpixel(m,n);
		colors[256]++;
	}
}
}
}


void extga(int*ex)
{
int m,n,i,j,flag;


	for(n=0;n<height;n++)
	{
	for(m=0;m<width;m++)
	{
		i=0;
		flag=0;
		do
		{
			if(getpixel(m,n)==ex[2*i])
			{
				putpixel(m,n,ex[2*i+1]);
				flag=1;
			}
		i++;
		}while(ex[2*i]!=-1 && flag==0);

	}
	}
}

float passdiff(int r1,int g1,int b1,int color, unsigned char*thepal)
{
int r2,g2,b2;

r2=thepal[color*3+0];
g2=thepal[color*3+1];
b2=thepal[color*3+2];

return ((float)(sqrt((r1-r2)*(r1-r2) + (g1-g2)*(g1-g2) + (b1-b2)*(b1-b2))));
}

int getclosest(int color,unsigned char*pal,unsigned char*thepal,int min,int max)
{
int closest,i,r1,g1,b1;
float value,temp;

value=10000;

r1=pal[color*3+0];
g1=pal[color*3+1];
b1=pal[color*3+2];

for(i=min;i<=max;i++)
{
	temp=passdiff(r1,g1,b1,i,thepal);
	if(temp<value)
	{
		value=temp;
		closest=i;
	}
}
return(closest);
}

void calcpassex(int*ex,int*colors,unsigned char*pal,unsigned char*thepal,int min,int max)
{
int i;

for(i=0;i<256*2;i++) ex[i]=-1;

for(i=0;i<colors[256];i++)
{
	ex[2*i+0]=colors[i];
	ex[2*i+1]=getclosest(colors[i],pal,thepal,min,max);
}
}

void passtgapal(unsigned char*pal,unsigned char*thepal,int min,int max)
{
int colors[257],ex[256*2];

get_TGA_colors(colors);
calcpassex(ex,colors,pal,thepal,min,max);
extga(ex);
}


void viewspr(char*filename,int*bredd,int*hojd)
{
int i,j;
char buffer[320];
FILE *fs;

   if (!(fs = fopen(filename, "rb")))
	  {
	  printf("Kan ej �ppna filen %s\n",filename);
	  getch();
	  exit(1);
	  }

fread(hojd, 2, 1, fs);
fread(bredd, 2, 1, fs);
for(i=0;i<*hojd;i++)
{
	fread(buffer, *bredd, 1, fs);
	for(j=0;j<*bredd;j++) putpixel(j,i,buffer[j]);
}
fclose(fs);
height=*hojd;
width=*bredd;
}

void savespr(char*filename,int*bredd,int*hojd)
{
int i,j;
char buffer[320];
FILE *fs;

   if (!(fs = fopen(filename, "wb")))
	  {
	  printf("Kan ej �ppna filen %s\n",filename);
	  getch();
	  exit(1);
	  }

fwrite(hojd, 2, 1, fs);
fwrite(bredd, 2, 1, fs);
for(i=0;i<*hojd;i++)
{
	for(j=0;j<*bredd;j++) buffer[j]=getpixel(j,i);
	fwrite(buffer, *bredd, 1, fs);
}
fclose(fs);

}

void main(void)
{
unsigned char pal[256*3],thepal[256*3];
unsigned char readnamn[40]="ball.spr"; //Input sprite
unsigned char writenamn[40]="balle.spr";//output sprite
int bredd,hojd;


 setmode(0x0013);
 loadpalett("palett.col",thepal); //the palette the sprite should be adjusted to fit
 loadpalett("ball.pal",pal);    //the sprite's palette

 setpal(pal);
 viewspr(readnamn,&bredd,&hojd);

 getch();

 passtgapal(pal,thepal,0,255);
 setpal(thepal);
 getch();

savespr(writenamn,&bredd,&hojd);

setmode(3);
}
